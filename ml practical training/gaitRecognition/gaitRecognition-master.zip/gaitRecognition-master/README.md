# gaitRecognition
步态识别行人

# 实验数据

文件夹 data 和 data2 中分别有10个txt文件，对应10个人的加速度传感器数据和陀螺仪传感器数据

# 实验算法

* RNN+GRU(128)+全连接(10)
* PCA+KNN
* CNN
* SVM

# 实验结果
![](20190503105739.png)

# TensorFlow版本1.14
