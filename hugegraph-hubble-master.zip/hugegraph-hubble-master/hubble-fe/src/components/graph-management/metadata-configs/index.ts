import MetadataConfigs from './MetadataConfigs';

export { MetadataConfigs };
