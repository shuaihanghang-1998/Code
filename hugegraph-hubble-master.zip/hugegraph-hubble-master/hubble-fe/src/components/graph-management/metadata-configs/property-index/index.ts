import PropertyIndex from './PropertyIndex';

export { PropertyIndex };
