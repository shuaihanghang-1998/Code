import DataAnalyze from './DataAnalyze';

export { DataAnalyze };
