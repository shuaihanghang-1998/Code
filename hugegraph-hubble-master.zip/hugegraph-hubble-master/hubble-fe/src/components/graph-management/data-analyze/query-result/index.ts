import QueryResult from './QueryResult';

export { QueryResult };
