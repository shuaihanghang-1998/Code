import JobDetails from './JobDetails';

export { JobDetails };
