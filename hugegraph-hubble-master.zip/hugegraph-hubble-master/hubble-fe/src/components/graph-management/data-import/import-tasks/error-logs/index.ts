import TaskErrorLogs from './TaskErrorLogs';
import JobErrorLogs from './JobErrorLogs';

export { TaskErrorLogs, JobErrorLogs };
