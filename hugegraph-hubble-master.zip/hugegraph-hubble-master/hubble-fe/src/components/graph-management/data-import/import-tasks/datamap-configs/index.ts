import DataMapConfigs from './DataMapConfigs';

export { DataMapConfigs };
