import zhCNResources from './zh-CN';

export { zhCNResources };
